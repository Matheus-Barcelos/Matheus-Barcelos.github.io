/**
 * 
 */

function buttonMouseOver(button){
	button.style.backgroundColor="black";
}

function buttonMouseOut(button){
	button.style.backgroundColor="gray";
}